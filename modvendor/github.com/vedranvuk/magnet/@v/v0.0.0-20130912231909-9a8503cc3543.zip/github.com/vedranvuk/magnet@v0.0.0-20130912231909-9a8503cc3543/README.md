# Description

Package magnet is a utility package for parsing magnet links.

# Installation

go get -u github.com/vedranvuk/magnet

# Usage

`m, err := NewMagnet(SomeMagnetString)`

# Version

It compiles. First commit, not ready.

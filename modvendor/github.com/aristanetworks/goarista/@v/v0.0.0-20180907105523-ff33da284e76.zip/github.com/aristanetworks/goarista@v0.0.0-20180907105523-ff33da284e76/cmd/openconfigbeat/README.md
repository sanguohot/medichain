# openconfigbeat

The code for `openconfigbeat` lives at [aristanetworks/openconfigbeat](https://github.com/aristanetworks/openconfigbeat).

cpuminer
========

[![Build Status](http://img.shields.io/travis/btcsuite/btcd.svg)](https://travis-ci.org/btcsuite/btcd)
[![ISC License](http://img.shields.io/badge/license-ISC-blue.svg)](http://copyfree.org)
[![GoDoc](https://img.shields.io/badge/godoc-reference-blue.svg)](http://godoc.org/github.com/btcsuite/btcd/mining/cpuminer)
=======

## Overview

This package is currently a work in progress.  It works without issue since it
is used in several of the integration tests, but the API is not really ready for
public consumption as it has simply been refactored out of the main codebase for
now.

## Installation and Updating

```bash
$ go get -u github.com/btcsuite/btcd/mining/cpuminer
```

## License

Package cpuminer is licensed under the [copyfree](http://copyfree.org) ISC
License.

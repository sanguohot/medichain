package testdata

import "testing"

func TestFoo1(t *testing.T) {
	tests := []struct {
		name string
	}{
	// TODO: Add test cases.
	}
	for range tests {
		Foo1()
	}
}
